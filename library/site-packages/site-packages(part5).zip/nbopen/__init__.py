"""Open a notebook from the command line in the best available server"""

__version__ = '0.6'

from .nbopen import main
