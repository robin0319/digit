from .nbopen import main
main()
