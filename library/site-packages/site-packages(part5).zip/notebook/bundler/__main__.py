# Copyright (c) Jupyter Development Team.
# Distributed under the terms of the Modified BSD License.

from .bundlerextensions import main

if __name__ == '__main__':    
    main()