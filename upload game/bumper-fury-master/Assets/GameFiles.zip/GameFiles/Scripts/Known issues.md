* Rapid toogling of D-Pad in android device is causing an exception
* Mini-map is not working on Air level while on Android
* Orthographic camera doesn't support water.