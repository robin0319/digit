﻿using UnityEngine;

public class Lava : MonoBehaviour
{
    //Public variables
    public float baseDamage = 0.1f;
}
