﻿using UnityEngine;

public class Oil : MonoBehaviour
{
}
