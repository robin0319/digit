﻿using UnityEngine;

public class Water : MonoBehaviour
{
    //Public variables
    public float baseDamage = 0.3f;
}
