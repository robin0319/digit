I updated the references as closer to the code as possible. But some references which reletes to the asesthetics of the project are mentioned here. 

 **Fonts**
* https://www.1001freefonts.com/deadpack-.font
* https://www.1001freefonts.com/gobold.font

**Andorid migration**
* https://www.youtube.com/watch?v=CcsUFGfdO_0

**Elemental orbs**
* https://opengameart.org/content/14-different-elemental-battle-orbs

**Unity asset-store**
* https://assetstore.unity.com/packages/vfx/particles/spells/48-particle-effect-pack-13998 - Car powers
* https://assetstore.unity.com/packages/audio/sound-fx/transportation/i6-german-free-engine-sound-pack-106037 - Car engine sound
* https://assetstore.unity.com/packages/audio/music/electronic/free-electronic-industrial-music-pack-162869 - Game music
* https://assetstore.unity.com/packages/audio/sound-fx/epic-arsenal-essential-elements-demo-packs-38428 - In game sounds
* https://assetstore.unity.com/packages/vfx/particles/fire-explosions/procedural-fire-141496 - To create elemental effects on cars
* https://assetstore.unity.com/packages/audio/sound-fx/grenade-sound-fx-147490 - Barel explosion sound
* https://assetstore.unity.com/packages/2d/textures-materials/floors/yughues-free-ground-materials-13001 - Level textures
* https://assetstore.unity.com/packages/2d/gui/icons/rpg-unitframes-1-powerful-metal-95252 - Player HUD
* https://assetstore.unity.com/packages/tools/input-management/joystick-pack-107631 - Implementing virtual joystick
* https://assetstore.unity.com/packages/2d/textures-materials/metals/yughues-free-metal-materials-12949 - Metal textures. For example on Ramps and Barels.
* https://assetstore.unity.com/packages/vfx/particles/powerup-particles-16458 - Power up particles
* https://assetstore.unity.com/publishers/34662 - Car models
* https://assetstore.unity.com/packages/vfx/particles/war-fx-5669 - Fire effects such as fire on damaged car and car nitros.
* https://assetstore.unity.com/packages/essentials/asset-packs/standard-assets-for-unity-2017-3-32351 - For water and dust storm
* https://assetstore.unity.com/packages/2d/textures-materials/brick/tileable-bricks-wall-24530 - Wall texture
