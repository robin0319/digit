# Paper.io-2
Clone of mobile game Paper.io 2 using Unity.

Made by FlopCoat - https://overlapstudio.org
